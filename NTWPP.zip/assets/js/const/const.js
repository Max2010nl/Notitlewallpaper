const NORMAL = 0, PROCESS = 1
const RADIAN = Math.PI / 180
const RATIO = window.devicePixelRatio
const SIMPLEX = new SimplexNoise()
let WIDTH = window.innerWidth, HEIGHT = window.innerHeight