const MapChildParam = {
    width: 1600,
    height: 1600,
    color: 0x32eaff,
    size: 6,
    y: 100,
    div: 0.05
}